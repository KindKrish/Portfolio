package com.example.krishmodule3;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

public class SMSReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        SharedPreferences preferences =
                context.getSharedPreferences(
                        "EventTrackerSMS",
                        Context.MODE_PRIVATE
                );

        boolean smsEnabled =
                preferences.getBoolean("sms_enabled", false);

        String phoneNumber =
                preferences.getString("phone_number", "");

        String eventName =
                intent.getStringExtra("EVENT_NAME");

        if (!smsEnabled || phoneNumber.isEmpty()
                || eventName == null) {
            return;
        }

        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        String message =
                "Event Tracker Reminder: Your event \""
                        + eventName
                        + "\" is coming up soon.";

        try {
            SmsManager smsManager;

            if (android.os.Build.VERSION.SDK_INT >= 31) {
                smsManager = context.getSystemService(
                        SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault();
            }

            if (smsManager != null) {
                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        message,
                        null,
                        null
                );
            }

        } catch (Exception e) {
            android.util.Log.e(
                    "SMSReminderReceiver",
                    "Unable to send SMS reminder",
                    e
            );
        }
    }
}
