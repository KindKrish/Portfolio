package com.example.krishmodule3;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class AddEventActivity extends AppCompatActivity {

    private EditText editEventName;
    private EditText editEventDate;
    private EditText editEventTime;
    private EditText editEventDescription;

    private DatabaseHelper databaseHelper;

    private long userId;
    private long eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        databaseHelper = new DatabaseHelper(this);

        userId = getIntent().getLongExtra("USER_ID", -1);
        eventId = getIntent().getLongExtra("EVENT_ID", -1);

        if (userId == -1) {
            Toast.makeText(this,
                    "Please log in again",
                    Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        editEventName = findViewById(R.id.editEventName);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editEventDescription =
                findViewById(R.id.editEventDescription);

        Button saveButton =
                findViewById(R.id.buttonSaveEvent);

        Button cancelButton =
                findViewById(R.id.buttonCancelEvent);

        if (eventId != -1) {
            loadEvent();
            saveButton.setText("Update Event");
        }

        saveButton.setOnClickListener(v -> saveEvent());

        cancelButton.setOnClickListener(v -> finish());
    }

    private void loadEvent() {

        try (Cursor cursor =
                     databaseHelper.getEvent(eventId, userId)) {

            if (cursor.moveToFirst()) {

                editEventName.setText(cursor.getString(
                        cursor.getColumnIndexOrThrow("title")));

                editEventDate.setText(cursor.getString(
                        cursor.getColumnIndexOrThrow("event_date")));

                editEventTime.setText(cursor.getString(
                        cursor.getColumnIndexOrThrow("event_time")));

                editEventDescription.setText(cursor.getString(
                        cursor.getColumnIndexOrThrow("description")));

            } else {

                Toast.makeText(this,
                        "Event not found",
                        Toast.LENGTH_SHORT).show();

                finish();
            }
        }
    }

    private boolean isValidDateTime(String date, String time) {

        SimpleDateFormat format =
                new SimpleDateFormat(
                        "MM/dd/yyyy hh:mm a",
                        Locale.US);

        format.setLenient(false);

        try {
            return format.parse(date + " " + time) != null;
        } catch (ParseException e) {
            return false;
        }
    }

    private void saveEvent() {

        String name =
                editEventName.getText().toString().trim();

        String date =
                editEventDate.getText().toString().trim();

        String time =
                editEventTime.getText().toString().trim();

        String description =
                editEventDescription.getText().toString().trim();

        if (name.isEmpty() || date.isEmpty() || time.isEmpty()) {

            Toast.makeText(this,
                    "Please enter event name, date, and time",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        if (!isValidDateTime(date, time)) {

            Toast.makeText(this,
                    "Use MM/DD/YYYY and HH:MM AM/PM",
                    Toast.LENGTH_LONG).show();

            return;
        }

        boolean success;

        if (eventId == -1) {

            // Add a new event to SQLite.
            long newEventId = databaseHelper.addEvent(
                    userId, name, date, time, description);

            success = newEventId != -1;

            if (success) {

                // Schedule the new event reminder.
                ReminderScheduler.scheduleReminder(
                        this,
                        newEventId,
                        name,
                        date,
                        time);
            }

        } else {

            // Update the existing event in SQLite.
            success = databaseHelper.updateEvent(
                    eventId,
                    userId,
                    name,
                    date,
                    time,
                    description);

            if (success) {

                // Remove the previous reminder.
                ReminderScheduler.cancelReminder(
                        this, eventId);

                // Schedule the updated reminder.
                ReminderScheduler.scheduleReminder(
                        this,
                        eventId,
                        name,
                        date,
                        time);
            }
        }

        if (success) {

            Toast.makeText(this,
                    eventId == -1
                            ? "Event saved successfully!"
                            : "Event updated successfully!",
                    Toast.LENGTH_SHORT).show();

            finish();

        } else {

            Toast.makeText(this,
                    "Unable to save event",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {

        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}
