package com.example.krishmodule3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect to the SQLite database.
        databaseHelper = new DatabaseHelper(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton =
                findViewById(R.id.buttonCreateAccount);

        // Check credentials when the user logs in.
        loginButton.setOnClickListener(v -> {
            String username =
                    editUsername.getText().toString().trim();
            String password =
                    editPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Please enter username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (databaseHelper.checkUser(username, password)) {
                long userId = databaseHelper.getUserId(username);

                if (userId != -1) {
                    Toast.makeText(this,
                            "Login successful!",
                            Toast.LENGTH_SHORT).show();

                    openDashboard(userId);
                } else {
                    Toast.makeText(this,
                            "Unable to find user account",
                            Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this,
                        "Invalid username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Create a new user account.
        createAccountButton.setOnClickListener(v -> {
            String username =
                    editUsername.getText().toString().trim();
            String password =
                    editPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Please enter username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean registered =
                    databaseHelper.registerUser(username, password);

            if (registered) {
                long userId = databaseHelper.getUserId(username);

                if (userId != -1) {
                    Toast.makeText(this,
                            "Account created successfully!",
                            Toast.LENGTH_SHORT).show();

                    openDashboard(userId);
                } else {
                    Toast.makeText(this,
                            "Unable to open new account",
                            Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this,
                        "Username already exists or registration failed",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Pass the user ID to the dashboard.
    private void openDashboard(long userId) {
        Intent intent = new Intent(
                MainActivity.this,
                DashboardActivity.class
        );

        intent.putExtra("USER_ID", userId);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }
        super.onDestroy();
    }
}
