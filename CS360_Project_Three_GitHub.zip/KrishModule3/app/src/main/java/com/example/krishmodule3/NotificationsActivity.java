package com.example.krishmodule3;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class NotificationsActivity extends AppCompatActivity {

    private EditText editPhoneNumber;
    private TextView textPermissionStatus;
    private SharedPreferences preferences;

    private ActivityResultLauncher<String> smsPermissionLauncher;

    private static final String PREFS_NAME = "EventTrackerSMS";
    private static final String KEY_PHONE = "phone_number";
    private static final String KEY_ENABLED = "sms_enabled";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        textPermissionStatus =
                findViewById(R.id.textPermissionStatus);

        Button enableButton =
                findViewById(R.id.buttonEnableSMS);

        Button skipButton =
                findViewById(R.id.buttonSkipSMS);

        preferences = getSharedPreferences(
                PREFS_NAME, Context.MODE_PRIVATE);

        // Restore the previously saved phone number.
        String savedPhone = preferences.getString(KEY_PHONE, "");
        editPhoneNumber.setText(savedPhone);

        // Receive the result of the SMS permission request.
        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {

                    if (isGranted) {
                        saveSMSSettings();

                        Toast.makeText(this,
                                "SMS notifications enabled!",
                                Toast.LENGTH_SHORT).show();

                    } else {
                        preferences.edit()
                                .putBoolean(KEY_ENABLED, false)
                                .apply();

                        Toast.makeText(this,
                                "SMS permission denied. You can still use the app.",
                                Toast.LENGTH_LONG).show();
                    }

                    updatePermissionStatus();
                }
        );

        // Enable SMS notifications when the user taps the button.
        enableButton.setOnClickListener(v -> enableSMS());

        // Continue using the app without SMS notifications.
        skipButton.setOnClickListener(v -> {
            preferences.edit()
                    .putBoolean(KEY_ENABLED, false)
                    .apply();

            Toast.makeText(this,
                    "Continuing without SMS notifications",
                    Toast.LENGTH_SHORT).show();

            finish();
        });

        updatePermissionStatus();
    }

    private void enableSMS() {

        String phoneNumber =
                editPhoneNumber.getText().toString().trim();

        // Make sure a phone number was entered.
        if (phoneNumber.isEmpty()) {
            editPhoneNumber.setError("Please enter a phone number");
            editPhoneNumber.requestFocus();
            return;
        }

        // Basic phone number validation.
        if (!PhoneNumberUtils.isGlobalPhoneNumber(phoneNumber)) {
            editPhoneNumber.setError("Enter a valid phone number");
            editPhoneNumber.requestFocus();
            return;
        }

        // Save the phone number before requesting permission.
        preferences.edit()
                .putString(KEY_PHONE, phoneNumber)
                .apply();

        // Check whether permission has already been granted.
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            saveSMSSettings();

            Toast.makeText(this,
                    "SMS notifications enabled!",
                    Toast.LENGTH_SHORT).show();

            updatePermissionStatus();

        } else {

            // Ask the user to approve SMS permission.
            smsPermissionLauncher.launch(
                    Manifest.permission.SEND_SMS);
        }
    }

    private void saveSMSSettings() {

        String phoneNumber =
                editPhoneNumber.getText().toString().trim();

        preferences.edit()
                .putString(KEY_PHONE, phoneNumber)
                .putBoolean(KEY_ENABLED, true)
                .apply();

        updatePermissionStatus();
    }

    private void updatePermissionStatus() {

        boolean hasPermission =
                ContextCompat.checkSelfPermission(
                        this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED;

        boolean enabled =
                preferences.getBoolean(KEY_ENABLED, false);

        if (hasPermission && enabled) {

            textPermissionStatus.setText(
                    "SMS Permission: Enabled");

            textPermissionStatus.setTextColor(
                    ContextCompat.getColor(
                            this, android.R.color.holo_green_dark));

        } else {

            textPermissionStatus.setText(
                    "SMS Notifications: Not Enabled");

            textPermissionStatus.setTextColor(
                    ContextCompat.getColor(
                            this, android.R.color.holo_red_dark));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (textPermissionStatus != null) {
            updatePermissionStatus();
        }
    }
}
