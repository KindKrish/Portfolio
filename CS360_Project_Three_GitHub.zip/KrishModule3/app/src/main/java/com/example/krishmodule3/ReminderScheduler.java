package com.example.krishmodule3;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReminderScheduler {

    private static final String TAG = "ReminderScheduler";

    public static void scheduleReminder(
            Context context,
            long eventId,
            String eventName,
            String eventDate,
            String eventTime) {

        try {
            SimpleDateFormat format =
                    new SimpleDateFormat(
                            "MM/dd/yyyy hh:mm a",
                            Locale.US);

            format.setLenient(false);

            Date date = format.parse(
                    eventDate + " " + eventTime);

            if (date == null) {
                return;
            }

            // Schedule the reminder one hour before the event.
            long reminderTime =
                    date.getTime() - (60 * 60 * 1000L);

            // Do not schedule reminders in the past.
            if (reminderTime <= System.currentTimeMillis()) {
                Log.d(TAG, "Reminder time has already passed");
                return;
            }

            AlarmManager alarmManager =
                    (AlarmManager) context.getSystemService(
                            Context.ALARM_SERVICE);

            if (alarmManager == null) {
                return;
            }

            Intent intent = new Intent(
                    context, SMSReminderReceiver.class);

            intent.putExtra("EVENT_NAME", eventName);

            PendingIntent pendingIntent =
                    PendingIntent.getBroadcast(
                            context,
                            (int) eventId,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT
                                    | PendingIntent.FLAG_IMMUTABLE);

            // Inexact alarms avoid requiring special
            // exact-alarm access on newer Android versions.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        reminderTime,
                        pendingIntent);

            } else {

                alarmManager.set(
                        AlarmManager.RTC_WAKEUP,
                        reminderTime,
                        pendingIntent);
            }

            Log.d(TAG, "Reminder scheduled");

        } catch (ParseException e) {

            Log.e(TAG,
                    "Invalid event date or time",
                    e);
        }
    }

    public static void cancelReminder(
            Context context,
            long eventId) {

        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(
                        Context.ALARM_SERVICE);

        Intent intent = new Intent(
                context, SMSReminderReceiver.class);

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        context,
                        (int) eventId,
                        intent,
                        PendingIntent.FLAG_NO_CREATE
                                | PendingIntent.FLAG_IMMUTABLE);

        if (alarmManager != null && pendingIntent != null) {
            alarmManager.cancel(pendingIntent);
            pendingIntent.cancel();
        }
    }
}
