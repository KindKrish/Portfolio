package com.example.krishmodule3;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private long userId;
    private DatabaseHelper databaseHelper;
    private TableLayout eventTable;
    private TextView textEmptyEvents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId == -1) {
            Toast.makeText(this,
                    "Please log in to continue",
                    Toast.LENGTH_SHORT).show();

            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);

        eventTable = findViewById(R.id.eventTable);
        textEmptyEvents = findViewById(R.id.textEmptyEvents);

        Button addEventButton =
                findViewById(R.id.buttonAddEvent);

        Button notificationButton =
                findViewById(R.id.buttonNotifications);

        // Open the Add Event screen.
        addEventButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this, AddEventActivity.class);

            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        // Open Notification Settings.
        notificationButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this, NotificationsActivity.class);

            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (databaseHelper != null) {
            loadEvents();
        }
    }

    // Load all events belonging to the logged-in user.
    private void loadEvents() {

        // Preserve the table header.
        if (eventTable.getChildCount() > 1) {
            eventTable.removeViews(
                    1,
                    eventTable.getChildCount() - 1);
        }

        int eventCount = 0;

        try (Cursor cursor =
                     databaseHelper.getAllEvents(userId)) {

            while (cursor.moveToNext()) {

                long eventId = cursor.getLong(
                        cursor.getColumnIndexOrThrow("_id"));

                String title = cursor.getString(
                        cursor.getColumnIndexOrThrow("title"));

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow("event_date"));

                addEventRow(eventId, title, date);
                eventCount++;
            }
        }

        textEmptyEvents.setVisibility(
                eventCount == 0
                        ? View.VISIBLE
                        : View.GONE);
    }

    // Display an event with Edit and Delete buttons.
    private void addEventRow(
            long eventId,
            String title,
            String date) {

        TableRow row = new TableRow(this);
        row.setPadding(4, 8, 4, 8);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(Color.DKGRAY);
        titleView.setPadding(6, 6, 6, 6);
        titleView.setLayoutParams(
                new TableRow.LayoutParams(0, -2, 1f));

        TextView dateView = new TextView(this);
        dateView.setText(date);
        dateView.setTextColor(Color.DKGRAY);
        dateView.setPadding(6, 6, 6, 6);
        dateView.setLayoutParams(
                new TableRow.LayoutParams(0, -2, 1f));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);

        // Edit an existing event.
        Button editButton = new Button(this);
        editButton.setText("Edit");
        editButton.setTextSize(11);

        editButton.setOnClickListener(v -> {

            Intent intent = new Intent(
                    this, AddEventActivity.class);

            intent.putExtra("USER_ID", userId);
            intent.putExtra("EVENT_ID", eventId);

            startActivity(intent);
        });

        // Delete an existing event.
        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setTextSize(11);

        deleteButton.setOnClickListener(v ->
                confirmDelete(eventId));

        actions.addView(editButton);
        actions.addView(deleteButton);

        row.addView(titleView);
        row.addView(dateView);
        row.addView(actions);

        eventTable.addView(row);
    }

    // Ask for confirmation before deleting an event.
    private void confirmDelete(long eventId) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage(
                        "Are you sure you want to delete this event?")

                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> {

                            boolean deleted =
                                    databaseHelper.deleteEvent(
                                            eventId, userId);

                            if (deleted) {

                                // Cancel the event's SMS reminder.
                                ReminderScheduler.cancelReminder(
                                        this, eventId);

                                Toast.makeText(
                                        this,
                                        "Event and reminder deleted",
                                        Toast.LENGTH_SHORT).show();

                                // Refresh the dashboard.
                                loadEvents();

                            } else {

                                Toast.makeText(
                                        this,
                                        "Unable to delete event",
                                        Toast.LENGTH_SHORT).show();
                            }
                        })

                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onDestroy() {

        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}
