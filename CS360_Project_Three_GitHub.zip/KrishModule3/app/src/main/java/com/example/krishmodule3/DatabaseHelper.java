package com.example.krishmodule3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EventTracker.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Store registered user accounts.
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL, " +
                "salt TEXT NOT NULL)");

        // Store events associated with each user.
        db.execSQL("CREATE TABLE events (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "title TEXT NOT NULL, " +
                "event_date TEXT, " +
                "event_time TEXT, " +
                "description TEXT, " +
                "FOREIGN KEY(user_id) REFERENCES users(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        // Handle future database upgrades here.
    }

    // Generate a unique random salt for each password.
    private String generateSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    // Hash a password before storing or comparing it.
    private String hashPassword(String password, String salt) {
        try {
            MessageDigest digest =
                    MessageDigest.getInstance("SHA-256");

            digest.update(Base64.decode(salt, Base64.NO_WRAP));

            byte[] hash = digest.digest(
                    password.getBytes(StandardCharsets.UTF_8));

            return Base64.encodeToString(hash, Base64.NO_WRAP);

        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(
                    "Password hashing failed", e);
        }
    }

    // CREATE: Register a new user.
    public boolean registerUser(String username, String password) {

        if (username == null || username.trim().isEmpty()
                || password == null || password.isEmpty()) {
            return false;
        }

        String salt = generateSalt();

        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("salt", salt);
        values.put("password_hash",
                hashPassword(password, salt));

        return getWritableDatabase().insert(
                "users", null, values) != -1;
    }

    // READ: Verify login credentials.
    public boolean checkUser(String username, String password) {

        if (username == null || password == null) {
            return false;
        }

        try (Cursor cursor = getReadableDatabase().query(
                "users",
                new String[]{"password_hash", "salt"},
                "username = ?",
                new String[]{username.trim()},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                String storedHash = cursor.getString(0);
                String salt = cursor.getString(1);
                String enteredHash = hashPassword(password, salt);

                return MessageDigest.isEqual(
                        Base64.decode(storedHash, Base64.NO_WRAP),
                        Base64.decode(enteredHash, Base64.NO_WRAP));
            }
        }

        return false;
    }

    // READ: Find a registered user's database ID.
    public long getUserId(String username) {

        try (Cursor cursor = getReadableDatabase().query(
                "users",
                new String[]{"id"},
                "username = ?",
                new String[]{username.trim()},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                return cursor.getLong(0);
            }
        }

        return -1;
    }

    // CREATE: Add a new event.
    public long addEvent(long userId, String title,
                         String date, String time,
                         String description) {

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("title", title);
        values.put("event_date", date);
        values.put("event_time", time);
        values.put("description", description);

        return getWritableDatabase().insert(
                "events", null, values);
    }

    // READ: Retrieve all events belonging to a user.
    // The caller must close the returned Cursor.
    public Cursor getAllEvents(long userId) {

        return getReadableDatabase().query(
                "events",
                new String[]{
                        "id AS _id",
                        "title",
                        "event_date",
                        "event_time",
                        "description"
                },
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "id DESC");
    }

    // READ: Retrieve one event for editing.
    // The caller must close the returned Cursor.
    public Cursor getEvent(long eventId, long userId) {

        return getReadableDatabase().query(
                "events",
                new String[]{
                        "id AS _id",
                        "title",
                        "event_date",
                        "event_time",
                        "description"
                },
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(eventId),
                        String.valueOf(userId)
                },
                null, null, null);
    }

    // UPDATE: Modify an existing event.
    public boolean updateEvent(long eventId, long userId,
                               String title, String date,
                               String time, String description) {

        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("event_date", date);
        values.put("event_time", time);
        values.put("description", description);

        int rowsUpdated = getWritableDatabase().update(
                "events",
                values,
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(eventId),
                        String.valueOf(userId)
                });

        return rowsUpdated > 0;
    }

    // DELETE: Remove an event from the database.
    public boolean deleteEvent(long eventId, long userId) {

        int rowsDeleted = getWritableDatabase().delete(
                "events",
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(eventId),
                        String.valueOf(userId)
                });

        return rowsDeleted > 0;
    }
}
